-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2024 at 05:38 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `techtitan`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_book`
--

CREATE TABLE `tbl_book` (
  `id` int(11) NOT NULL,
  `book_name` varchar(250) NOT NULL,
  `isbnno` varchar(250) NOT NULL,
  `author` varchar(250) NOT NULL,
  `publisher` varchar(250) NOT NULL,
  `price` varchar(250) NOT NULL,
  `quantity` varchar(250) NOT NULL,
  `place` varchar(250) NOT NULL,
  `category` varchar(250) NOT NULL,
  `availability` tinyint(1) NOT NULL DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `text_file` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_book`
--

INSERT INTO `tbl_book` (`id`, `book_name`, `isbnno`, `author`, `publisher`, `price`, `quantity`, `place`, `category`, `availability`, `image`, `text_file`, `created_at`) VALUES
(15, 'ChatGPT', '1029380', 'Michael', 'PT Nassa Bekasi', '', '0', 'JAKAL', 'Horror', 1, 'download (1).jpg', NULL, '2024-12-21 16:52:12'),
(16, 'Kumpulan Dongeng', '102938', 'Mark', 'Cahaya redup', '', '2', 'Sleman', 'Tutorial', 1, 'download.jpg', NULL, '2024-12-22 16:32:27'),
(17, 'Misteri klitih sleman', '123456', 'Parno', 'PT Antemi', '', '2', 'JAKAL', 'Horror', 1, 'download (2).jpg', NULL, '2024-12-21 14:41:18'),
(19, 'Buku Pelajaran', '123456', 'Michael', 'PT Nassa Bekasi', '', '2', 'Sleman', 'Tutorial', 1, 'images.jpg', NULL, '2024-12-22 16:32:05'),
(21, 'Cara hack nassa', '098765', 'Yanto', 'PT Antemi', '', '1', 'JAKAL', 'Tutorial', 1, 'images.jpg', NULL, '2024-12-21 14:37:13'),
(22, 'Ritual', '098765', 'Mark', 'PT. Bertaubat', '', '2', 'Sleman', 'Horror', 1, 'download (2).jpg', NULL, '2024-12-22 16:31:42'),
(24, 'Misterii', '123456', 'Michael', 'PT Antemi', '', '2', 'Sleman', 'Tutorial', 1, 'download (2).jpg', NULL, '2024-12-22 16:33:47'),
(25, 'ChatGPT', '123456', 'Mark', 'PT Nassa Bekasi', '', '1', 'JAKAL', 'AI', 1, 'images.jpg', NULL, '2024-12-21 14:38:06'),
(27, 'Tudung merah', '09876565', 'Mark', 'Cahaya redup', '', '1', 'Sleman', 'AI', 1, 'download (1).jpg', NULL, '2024-12-22 16:31:15'),
(28, 'Tutor Ngehack Kampus', '09876565', 'Michael', 'Tesla', '', '1', 'JAKAL', 'Tutorial', 1, 'images.jpg', NULL, '2024-12-21 15:16:44'),
(29, 'Cara hack nassa', '09876565', 'Parno', 'Cahaya redup', '', '2', 'Sleman', 'Horror', 1, 'download (3).jpg', 'Bacaan.txt', '2024-12-21 16:54:43'),
(30, 'Kancil pintar', '09876565-99229294', 'Jokowi', 'PT. Bertaubat', '', '1', 'Sleman', 'Dongeng', 1, 'download (4).jpg', 'dongeng.txt', '2024-12-22 16:30:52'),
(31, 'Tutorial Hack Pemula', '35039503939-09402924-22991825', 'Prabowo', 'PT Antemi', '0', '1', 'Sleman', 'Tutorial', 1, 'download (5).jpg', 'dongeng.txt', '2024-12-22 10:23:17'),
(32, 'Tutor menangkap klitih', '102938', 'Yanto', 'PT. Bertaubat', '', '1', 'JAKAL', 'Horror', 1, 'download (6).jpg', 'Tutorial hack.txt', '2024-12-22 16:30:39');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(250) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1=active, 0=inactive',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `category_name`, `status`, `created_at`) VALUES
(1, 'Horror', 1, '2024-12-14 12:55:11'),
(2, 'Tutorial', 1, '2024-12-15 08:19:52'),
(3, 'AI', 1, '2024-12-15 10:24:30'),
(4, 'Dongeng', 1, '2024-12-21 20:04:42');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_issue`
--

CREATE TABLE `tbl_issue` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(250) NOT NULL,
  `issue_date` varchar(250) NOT NULL,
  `due_date` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL DEFAULT '0' COMMENT '3=request sent, 1=accept, 2=reject',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_issue`
--

INSERT INTO `tbl_issue` (`id`, `book_id`, `user_id`, `user_name`, `issue_date`, `due_date`, `status`, `created_at`) VALUES
(5, 3, 4, 'asep', '2024-12-15', '2025-03-15', '1', '2024-12-15 11:11:42'),
(6, 2, 2, 'eep', '', '', '3', '2024-12-16 03:09:59'),
(8, 4, 3, 'eep', '2024-12-20', '2025-03-20', '1', '2024-12-20 16:13:54'),
(9, 4, 1, 'eep', '2024-12-20', '2025-03-20', '1', '2024-12-20 16:13:57'),
(15, 4, 4, 'asep', '2024-12-20', '2025-03-19', '1', '2024-12-19 18:45:29'),
(16, 5, 4, 'asep', '', '', '0', '2024-12-18 14:38:52'),
(17, 5, 2, 'eep', '', '', '3', '2024-12-19 09:31:47'),
(24, 15, 2, 'eep', '2024-12-21', '2025-03-21', '0', '2024-12-21 16:52:12'),
(25, 16, 2, 'eep', '2024-12-21', '2025-03-21', '0', '2024-12-21 16:52:09'),
(26, 29, 2, 'eep', '2024-12-21', '2025-03-21', '1', '2024-12-21 16:54:43'),
(27, 15, 2, 'eep', '', '', '3', '2024-12-21 19:59:43'),
(28, 30, 2, 'eep', '2024-12-22', '2025-03-21', '1', '2024-12-21 20:09:12'),
(29, 31, 2, 'eep', '2024-12-22', '2025-03-22', '1', '2024-12-22 10:23:17'),
(30, 32, 2, 'eep', '2024-12-22', '2025-03-22', '1', '2024-12-22 16:11:02');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_location`
--

CREATE TABLE `tbl_location` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1=active, 0=inactive',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_location`
--

INSERT INTO `tbl_location` (`id`, `name`, `status`, `created_at`) VALUES
(1, 'JAKAL', 1, '2024-12-14 12:56:53'),
(2, 'Sleman', 1, '2024-12-15 07:52:50'),
(3, 'Bantul', 1, '2024-12-20 14:13:27');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_return`
--

CREATE TABLE `tbl_return` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(250) NOT NULL,
  `return_date` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_return`
--

INSERT INTO `tbl_return` (`id`, `book_id`, `user_id`, `user_name`, `return_date`, `created_at`) VALUES
(1, 1, 2, 'eep', '2024-12-15', '2024-12-15 04:28:42'),
(2, 2, 2, 'eep', '2024-12-15', '2024-12-15 11:06:38'),
(3, 2, 4, 'asep', '2024-12-15', '2024-12-15 11:10:34'),
(4, 4, 2, 'eep', '2024-12-17', '2024-12-17 12:55:50'),
(5, 5, 2, 'eep', '2024-12-17', '2024-12-17 13:56:54'),
(6, 5, 2, 'eep', '2024-12-18', '2024-12-18 14:38:28'),
(7, 5, 2, 'eep', '2024-12-18', '2024-12-18 14:38:52'),
(8, 4, 2, 'eep', '2024-12-19', '2024-12-19 09:31:26'),
(9, 6, 2, 'eep', '2024-12-19', '2024-12-19 09:31:29'),
(10, 1, 2, 'eep', '2024-12-21', '2024-12-21 06:41:18'),
(11, 15, 2, 'eep', '2024-12-21', '2024-12-21 14:41:12'),
(12, 16, 2, 'eep', '2024-12-21', '2024-12-21 14:41:16'),
(13, 17, 2, 'eep', '2024-12-21', '2024-12-21 14:41:18'),
(14, 19, 2, 'eep', '2024-12-21', '2024-12-21 14:41:21'),
(15, 16, 4, 'asep', '2024-12-21', '2024-12-21 16:52:09'),
(16, 15, 4, 'asep', '2024-12-21', '2024-12-21 16:52:12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(250) NOT NULL,
  `emailid` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` tinyint(4) NOT NULL COMMENT '1=admin, 2=user',
  `status` tinyint(4) NOT NULL COMMENT '1=active, 0=inactive',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `user_name`, `emailid`, `password`, `role`, `status`, `created_at`) VALUES
(1, 'Admin', 'admin@library.com', '6b8d5de3b53751bac499eb1bef762a2a', 1, 1, '2023-05-27 13:29:44'),
(2, 'eep', 'eep@123', '85c5b6e775f9a69539734ec6bccbb049', 2, 1, '2024-12-15 04:27:57'),
(3, 'john', 'john@123', '6e0b7076126a29d5dfcbd54835387b7b', 1, 1, '2024-12-15 05:10:39'),
(4, 'asep', 'asep@098', '17beedc0728e45afed266b79de94e29c', 2, 1, '2024-12-15 08:42:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_book`
--
ALTER TABLE `tbl_book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_issue`
--
ALTER TABLE `tbl_issue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_location`
--
ALTER TABLE `tbl_location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_return`
--
ALTER TABLE `tbl_return`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_book`
--
ALTER TABLE `tbl_book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_issue`
--
ALTER TABLE `tbl_issue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tbl_location`
--
ALTER TABLE `tbl_location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_return`
--
ALTER TABLE `tbl_return`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
