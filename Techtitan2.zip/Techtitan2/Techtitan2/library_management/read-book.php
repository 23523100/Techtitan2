<?php
session_start();
include('connection.php');

// Validasi sesi pengguna
$name = isset($_SESSION['name']) ? $_SESSION['name'] : '';
$id = isset($_SESSION['id']) ? $_SESSION['id'] : '';
if (empty($id)) {
    header("Location: index.php"); 
    exit;
}

// Inisialisasi variabel pencarian
$search = '';
if (isset($_POST['search'])) {
    $search = mysqli_real_escape_string($conn, $_POST['search']); 
}

// Query untuk mengambil buku yang dipinjam oleh user
$select_query = "
    SELECT 
        b.* 
    FROM 
        tbl_book b
    INNER JOIN 
        tbl_issue i ON b.id = i.book_id
    WHERE 
        i.user_id = '$id' 
        AND i.status = 1
";

if (!empty($search)) {
    $select_query .= " AND (b.book_name LIKE '%$search%' OR b.author LIKE '%$search%' OR b.category LIKE '%$search%')";
}
$select_query .= " ORDER BY i.issue_date DESC";
$result = mysqli_query($conn, $select_query);

// Cek apakah ada buku yang dipinjam
$has_books = mysqli_num_rows($result) > 0;
?>

<?php include('include/header.php'); ?>

<div id="wrapper">
    <?php include('include/side-bar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Baca Buku</a>
                </li>
            </ol>

            <!-- Search Bar -->
            <div class="card mb-3">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="m-0">Daftar Buku yang Dipinjam</h5>
                        <form method="POST" action="" class="search-form">
                            <div class="input-group">
                                <input type="text" name="search" class="form-control" placeholder="Cari judul, penulis, atau kategori..." value="<?php echo htmlspecialchars($search); ?>">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                
                <div class="card-body">
                    <?php if ($has_books) { ?>
                        <div class="container-fluid view-book">
                            <div class="row">
                                <?php while($row = mysqli_fetch_array($result)) { ?>
                                    <div class="col-md-3">
                                        <div class="book-card">
                                            <div class="book-cover">
                                                <img src="uploads/<?php echo $row['image']; ?>" alt="<?php echo $row['book_name']; ?>">
                                                <div class="hover-info">
                                                    <h6><?php echo $row['book_name']; ?></h6>
                                                    <p class="author">Penulis: <?php echo $row['author']; ?></p>
                                                    <p class="category">Kategori: <?php echo $row['category']; ?></p>
                                                    <a href="read-text.php?id=<?php echo $row['id']; ?>" class="btn btn-read">BACA</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    <?php } else { ?>
                        <div class="empty-state">
                            <div class="empty-state-icon">
                                <i class="fas fa-books"></i>
                            </div>
                            <h3>Belum Ada Buku yang Dipinjam</h3>
                            <p>Silakan pinjam buku terlebih dahulu untuk membacanya.</p>
                            <a href="book.php" class="btn btn-primary">Pinjam Buku</a>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Search Form Styling */
.search-form {
    max-width: 400px;
    width: 100%;
}

.search-form .input-group {
    border-radius: 25px;
    overflow: hidden;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

.search-form .form-control {
    border: none;
    padding: 12px 20px;
}

.search-form .btn {
    padding: 0 20px;
    background: linear-gradient(45deg, #4facfe, #00f2fe);
    border: none;
}

/* Book Card Styling */
.book-card {
    margin-bottom: 30px;
    transition: all 0.3s ease;
}

.book-cover {
    position: relative;
    overflow: hidden;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.book-cover img {
    width: 100%;
    height: 350px;
    object-fit: cover;
    transition: all 0.3s ease;
}

.hover-info {
    position: absolute;
    bottom: -100%;
    left: 0;
    width: 100%;
    padding: 20px;
    background: linear-gradient(to top, rgba(0,0,0,0.9), rgba(0,0,0,0.7));
    color: white;
    transition: all 0.3s ease;
}

.book-cover:hover .hover-info {
    bottom: 0;
}

.book-cover:hover img {
    transform: scale(1.05);
}

.hover-info h6 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 8px;
}

.hover-info .author,
.hover-info .category {
    font-size: 14px;
    margin-bottom: 5px;
    opacity: 0.8;
}

.btn-read {
    display: inline-block;
    padding: 8px 25px;
    background: linear-gradient(45deg, #4facfe, #00f2fe);
    color: white;
    border-radius: 25px;
    text-transform: uppercase;
    font-size: 14px;
    font-weight: 600;
    margin-top: 10px;
    transition: all 0.3s ease;
}

.btn-read:hover {
    background: linear-gradient(45deg, #00f2fe, #4facfe);
    transform: translateY(-2px);
    color: white;
    text-decoration: none;
}

/* Responsive Adjustments */
@media (max-width: 1200px) {
    .book-cover img {
        height: 300px;
    }
}

@media (max-width: 992px) {
    .book-cover img {
        height: 280px;
    }
}

@media (max-width: 768px) {
    .search-form {
        max-width: 100%;
        margin-top: 15px;
    }
    
    .book-cover img {
        height: 400px;
    }
}

@media (max-width: 576px) {
    .book-cover img {
        height: 350px;
    }
    
    .hover-info {
        padding: 15px;
    }
}

/* Empty State Styling */
.empty-state {
    text-align: center;
    padding: 40px 20px;
}

.empty-state-icon {
    font-size: 48px;
    color: #ccc;
    margin-bottom: 20px;
}

.empty-state h3 {
    color: #333;
    font-size: 24px;
    margin-bottom: 10px;
}

.empty-state p {
    color: #666;
    margin-bottom: 20px;
}

.empty-state .btn {
    background: linear-gradient(45deg, #4facfe, #00f2fe);
    border: none;
    padding: 10px 30px;
    border-radius: 25px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.empty-state .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(79, 172, 254, 0.3);
}
</style>

<?php include('include/footer.php'); ?>
