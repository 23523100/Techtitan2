<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sidebar</title>
 
</head>
<body>
<div class="sidebar">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="dashboard_user.php">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="book.php">
                <i class="fas fa-book"></i>
                <span>Peminjaman</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="issued-book.php">
                <i class="fas fa-book-open"></i>
                <span>Pengembalian</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="read-book.php">
                <i class="fas fa-book-reader"></i>
                <span>Baca Buku</span>
            </a>
        </li>
    </ul>
</div>
</body>
</html>
