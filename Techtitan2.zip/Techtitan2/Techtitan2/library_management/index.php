<?php
session_start();
include('connection.php');
if (isset($_REQUEST['login_btn'])) {
    $uname = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['pwd']);
    $upwd = md5($password);

    $select_query = mysqli_query($conn, "SELECT user_name, id FROM tbl_users WHERE emailid='$uname' AND password='$upwd' AND role=2 AND status=1");
    $username = mysqli_fetch_row($select_query);
    if (!empty($username)) {
        $_SESSION['user_name'] = $username[0];
        $_SESSION['id'] = $username[1];
    }
    $rows = mysqli_num_rows($select_query);

    if ($rows > 0) {
        header("Location: dashboard_user.php");
    } else {
        echo "<script>alert('You have entered wrong emailid or password.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library_Tech - Login</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="css/stylelogin.css" rel="stylesheet">
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="login-content">
                <div class="login-header">
                    <div class="logo">
                        <i class="fas fa-user-circle"></i>
                    </div>
                    <form method="POST" action="">
                        <div class="input-field">
                            <i class="fas fa-user"></i>
                            <input type="text" name="email" required>
                            <label>Email</label>
                        </div>
                        <div class="input-field">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="pwd" required>
                            <label>Password</label>
                        </div>
                        <div class="remember-forgot">
                            <label><input type="checkbox"> Remember me</label>
                            <a href="#">Forgot password?</a>
                        </div>
                        <button type="submit" name="login_btn" class="login-btn">LOGIN</button>
                    </form>
                </div>
            </div>
            <div class="welcome-section">
                <div class="welcome-text">
                    <h2>Welcome.</h2>
                    <p>to Library Tech Management System</p>
                </div>
                <div class="wave-group">
                    <div class="wave wave1"></div>
                    <div class="wave wave2"></div>
                    <div class="wave wave3"></div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
