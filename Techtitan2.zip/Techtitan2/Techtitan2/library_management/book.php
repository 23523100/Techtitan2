<?php
session_start();
include ('connection.php');
$name = $_SESSION['user_name'];
$ids = $_SESSION['id'];
if(empty($ids))
{
    header("Location: index.php"); 
}

?>

<?php include('include/header.php'); ?>
  <div id="wrapper">

    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">View Book</a>
          </li>
        </ol>

        <!-- Search Form -->
        <form method="GET" action="">
          <div class="input-group mb-3">
            <input type="text" name="search" class="form-control" placeholder="Cari buku berdasarkan nama, kategori, atau penulis" value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
            <div class="input-group-append">
              <button class="btn btn-primary" type="submit">Cari</button>
            </div>
          </div>
        </form>

        <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-info-circle"></i>
            View Book Details</div>
            <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>S.No.</th>
                    <th>Gambar</th>
                    <th>Nama</th>
                    <th>Kategori</th>
                    <th>Penulis</th>
                    <th>ISBN</th>
                    <th>Ketersediaan</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  if(isset($_GET['ids'])){
                    $id = $_GET['ids'];
                    $delete_query = mysqli_query($conn, "DELETE FROM tbl_book WHERE id='$id'");
                  }

                  $search_query = "";
                  if(isset($_GET['search']) && !empty($_GET['search'])){
                    $search = mysqli_real_escape_string($conn, $_GET['search']);
                    $search_query = "AND (book_name LIKE '%$search%' OR category LIKE '%$search%' OR author LIKE '%$search%')";
                  }

                  $select_query = mysqli_query($conn, "SELECT * FROM tbl_book WHERE availability=1 $search_query");
                  $sn = 1;
                  while($row = mysqli_fetch_array($select_query))
                  { 
                    $imagePath = "uploads/" . $row['image'];
                    if (!file_exists($imagePath) || empty($row['image'])) {
                        $imagePath = "uploads/default.jpg"; // Gambar default jika tidak ditemukan
                    }
                  ?>
                    <tr>
                      <td><?php echo $sn; ?></td>
                      <td><img src="<?php echo $imagePath; ?>" alt="<?php echo $row['book_name']; ?>" style="width: 50px; height: auto;"></td>
                      <td><?php echo $row['book_name']; ?></td>
                      <td><?php echo $row['category']; ?></td>
                      <td><?php echo $row['author']; ?></td>
                      <td><?php echo $row['isbnno']; ?></td>
                      <?php if($row['availability']==1){ ?>
                        <td><span class="badge badge-success">Tersedia</span></td>
                      <?php } else { ?>
                        <td><span class="badge badge-danger">Kosong</span></td>
                      <?php } 

                      $id = $row['id'];
                      $fetch_issue_details = mysqli_query($conn, "SELECT status FROM tbl_issue WHERE user_id='$ids' AND book_id='$id'");
                      $res = mysqli_fetch_row($fetch_issue_details);
                      if(!empty($res)){
                        $res = $res[0];
                      }
                      if($res==1){ ?>
                        <td><span class="badge badge-success">Berhasil</span></td>
                      <?php } else if($res==2){ ?>
                        <td><span class="badge badge-danger">Ditolak</span></td>
                      <?php } else if($res==3){ ?>
                        <td><span class="badge badge-primary">Request Peminjaman</span></td>
                      <?php } else { ?>
                        <td><a href="book-issue.php?id=<?php echo $row['id']; ?>"><button class="btn btn-success">Pinjam</button></a></td>
                      <?php } ?>
                    </tr>
                  <?php $sn++; } ?>
                </tbody>
              </table>
            </div>
          </div>                   
        </div>
      </div>
    </div>
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>
<?php include('include/footer.php'); ?>
<script language="JavaScript" type="text/javascript">
function confirmDelete(){
    return confirm('Are you sure want to delete this Book?');
}
</script>
