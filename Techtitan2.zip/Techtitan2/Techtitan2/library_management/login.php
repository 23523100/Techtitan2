<?php
// Redirect ke halaman login admin yang sudah unified
header("Location: admin/index.php");
exit();
?> 