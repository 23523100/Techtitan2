<?php
session_start();
include('connection.php');

// Validasi sesi pengguna
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$name = isset($_SESSION['name']) ? $_SESSION['name'] : ''; // Ambil nama dari sesi pengguna
if ($id <= 0 || empty($name)) {
    header("Location: index.php"); // Kembali ke halaman daftar buku
    exit;
}

// Ambil isi file teks berdasarkan ID buku dengan prepared statements untuk keamanan
$query = "
    SELECT 
        b.book_name, 
        b.text_file 
    FROM 
        tbl_book AS b 
    WHERE 
        b.id = ?
";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id); // Binding parameter
$stmt->execute();
$result = $stmt->get_result();

// Pastikan data ditemukan
if ($row = $result->fetch_assoc()) {
    $bookName = $row['book_name'];
    $textFilePath = "uploads/text_files/" . $row['text_file'];

    // Cek apakah file teks ada
    if (!file_exists($textFilePath)) {
        echo "<script>alert('File teks tidak ditemukan.'); window.location.href = 'read-book.php';</script>";
        exit;
    }

    // Baca isi file teks
    $textContent = file_get_contents($textFilePath);
} else {
    echo "<script>alert('Buku tidak ditemukan atau belum ada teks.'); window.location.href = 'read-book.php';</script>";
    exit;
}

// Menutup statement setelah selesai
$stmt->close();
?>

<?php include('include/header.php'); ?>
<div class="container mt-5">
    <h2><?php echo htmlspecialchars($bookName); ?></h2>
    <div class="card">
        <div class="card-body">
            <!-- Menampilkan teks dengan aman -->
            <pre><?php echo nl2br(htmlspecialchars($textContent)); ?></pre>
        </div>
    </div>
    <a href="read-book.php" class="btn btn-secondary mt-3">Kembali</a>
</div>
<?php include('include/footer.php'); ?>
