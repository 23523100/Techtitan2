(function($) {
    "use strict"

    tinymce.init({
        selector: '#email-compose-editor'
    });


})(jQuery);