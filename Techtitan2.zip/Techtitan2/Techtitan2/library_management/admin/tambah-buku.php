<?php
session_start();
include('../connection.php');

// Validasi sesi pengguna
if (!isset($_SESSION['id']) || empty($_SESSION['id'])) {
    header("Location: index.php");
    exit;
}

$id = $_SESSION['id'];
$name = isset($_SESSION['name']) ? $_SESSION['name'] : '';

// Jika tombol submit ditekan
if (isset($_POST['sbt-book-btn'])) {
    // Ambil nilai dari form dengan validasi isset untuk mencegah undefined index
    $book_name = isset($_POST['book_name']) ? mysqli_real_escape_string($conn, trim($_POST['book_name'])) : '';
    $category_name = isset($_POST['category_name']) ? mysqli_real_escape_string($conn, trim($_POST['category_name'])) : '';
    $isbn = isset($_POST['isbn']) ? mysqli_real_escape_string($conn, trim($_POST['isbn'])) : '';
    $author_name = isset($_POST['author_name']) ? mysqli_real_escape_string($conn, trim($_POST['author_name'])) : '';
    $publisher_name = isset($_POST['publisher_name']) ? mysqli_real_escape_string($conn, trim($_POST['publisher_name'])) : '';
    $price = isset($_POST['price']) ? mysqli_real_escape_string($conn, trim($_POST['price'])) : '0';
    $quantity = isset($_POST['quantity']) ? mysqli_real_escape_string($conn, trim($_POST['quantity'])) : '0';
    $location_name = isset($_POST['location_name']) ? mysqli_real_escape_string($conn, trim($_POST['location_name'])) : '';
    $availability = isset($_POST['availability']) ? mysqli_real_escape_string($conn, trim($_POST['availability'])) : 'Unavailable';

    // Handle file upload for image
    $image_name = isset($_FILES['book_image']['name']) ? $_FILES['book_image']['name'] : '';
    $target_dir = "../uploads/";
    $target_file = $target_dir . basename($image_name);

    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0755, true); // Membuat folder jika belum ada
    }

    // Handle file upload for text file
    $text_file_name = isset($_FILES['text_file']['name']) ? $_FILES['text_file']['name'] : '';
    $text_target_dir = "../uploads/text_files/";
    $text_target_file = $text_target_dir . basename($text_file_name);

    if (!is_dir($text_target_dir)) {
        mkdir($text_target_dir, 0755, true); // Membuat folder jika belum ada
    }

    // Upload image file
    if (!empty($image_name) && move_uploaded_file($_FILES['book_image']['tmp_name'], $target_file)) {
        // Upload text file
        if (!empty($text_file_name) && move_uploaded_file($_FILES['text_file']['tmp_name'], $text_target_file)) {
            // Insert ke database
            $insert_book_query = "
                INSERT INTO tbl_book 
                (book_name, category, isbnno, author, publisher, price, quantity, place, availability, image, text_file) 
                VALUES 
                ('$book_name', '$category_name', '$isbn', '$author_name', '$publisher_name', '$price', '$quantity', '$location_name', '$availability', '$image_name', '$text_file_name')
            ";

            $insert_book = mysqli_query($conn, $insert_book_query);

            if ($insert_book) {
                echo "<script>alert('Book added successfully.');</script>";
            } else {
                echo "<script>alert('Error adding book: " . mysqli_error($conn) . "');</script>";
            }
        } else {
            echo "<script>alert('Failed to upload text file. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('Failed to upload image. Please try again.');</script>";
    }
}
?>

<!-- HTML Form -->
<?php include('include/header.php'); ?>
<div id="wrapper">
<?php include('include/side-bar.php'); ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <ol ```php
        <li class="breadcrumb-item"><a href="#">Add Book</a></li>
        </ol>
        <div class="card mb-3">
            <div class="card-header">
                <i class="fa fa-info-circle"></i> Submit Book Details
            </div>
            <form method="post" enctype="multipart/form-data" class="form-valide">
                <div class="card-body">
                    <!-- Nama Buku -->
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="book_name">Nama Buku <span class="text-danger">*</span></label>
                        <div class="col-lg-6">
                            <input type="text" name="book_name" id="book_name" class="form-control" placeholder="Masukkan Nama Buku" required>
                        </div>
                    </div>
                    <!-- Kategori -->
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="category_name">Kategori <span class="text-danger">*</span></label>
                        <div class="col-lg-6">
                            <select class="form-control" id="category_name" name="category_name" required>
                                <option value="">Pilih Kategori</option>
                                <?php 
                                $fetch_category = mysqli_query($conn, "SELECT * FROM tbl_category WHERE status=1");
                                while ($rows = mysqli_fetch_array($fetch_category)) {
                                    echo "<option value='{$rows['category_name']}'>{$rows['category_name']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <!-- ISBN -->
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="isbn">ISBN <span class="text-danger">*</span></label>
                        <div class="col-lg-6">
                            <input type="text" name="isbn" id="isbn" class="form-control" placeholder="Masukkan Nomor" required>
                        </div>
                    </div>
                    <!-- Penulis -->
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="author_name">Penulis <span class="text-danger">*</span></label>
                        <div class="col-lg-6">
                            <input type="text" name="author_name" id="author_name" class="form-control" placeholder="Masukkan Penulis Buku" required>
                        </div>
                    </div>
                    <!-- Penerbit -->
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="publisher_name">Penerbit <span class="text-danger">*</span></label>
                        <div class="col-lg-6">
                            <input type="text" name="publisher_name" id="publisher_name" class="form-control" placeholder="Masukkan Penerbit Buku" required>
                        </div>
                    </div>
                    <!-- Jumlah -->
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="quantity">Jumlah <span class="text-danger">*</span></label>
                        <div class="col-lg-6">
                            <input type="number" name="quantity" id="quantity" class="form-control" placeholder="Masukkan Nomor" required>
                        </div>
                    </div>
                    <!-- Lokasi -->
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="location_name">Lokasi <span class="text-danger">*</span></label>
                        <div class="col-lg-6">
                            <select class="form-control" id="location_name" name="location_name" required>
                                <option value="">Pilih Lokasi</option>
                                <?php 
                                $fetch_location = mysqli_query($conn, "SELECT * FROM tbl_location WHERE status=1");
                                while($rows = mysqli_fetch_array($fetch_location)){
                                    echo "<option value='{$rows['name']}'>{$rows['name']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <!-- Ketersediaan -->
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="availability">Availability <span class="text-danger">*</span></label>
                        <div class="col-lg-6">
                            <select class="form-control" id="availability" name="availability" required>
                                <option value="">Select Status</option>
                                <option value="1">Tersedia</option>
                                <option value="0">Kosong</option>
                            </select>
                        </div>
                    </div>
                    
                     <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="book_image">Image <span class="text-danger">*</span></label>
                        <div class="col-lg-6">
                            <input type="file" name="book_image" id="book_image" class="form-control" required>
                        </div>  
                    </div>
                    <!-- File Teks -->
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="text_file">Upload Text File <span class="text-danger">*</span></label>
                        <div class="col-lg-6">
                            <input type="file" name="text_file" id="text_file" class="form-control" accept=".txt" required>
                        </div>
                    </div>
                    <!-- Tombol Submit -->
                    <div class="form-group row">
                        <div class="col-lg-8 ml-auto">
                            <button type="submit" name="sbt-book-btn" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include('include/footer.php'); ?>