<?php
session_start();
include('../connection.php'); // File koneksi ke database

// Hapus session yang ada saat mengakses halaman login
if (isset($_SESSION['id']) || isset($_SESSION['name']) || isset($_SESSION['role'])) {
    session_unset();
    session_destroy();
    session_start(); // Mulai session baru
}

if (isset($_POST['login_btn'])) {
    // Ambil input email dan password
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['pwd']);
    $pwd = md5($password); // Enkripsi password dengan MD5

    // Query untuk memeriksa role pengguna
    $query = "SELECT id, user_name, role FROM tbl_users WHERE emailid='$email' AND password='$pwd' AND status=1";
    $result = mysqli_query($conn, $query);

    // Periksa hasil query
    if ($result && mysqli_num_rows($result) > 0) {
        $user_data = mysqli_fetch_assoc($result);

        // Set session berdasarkan data pengguna
        $_SESSION['id'] = $user_data['id'];
        $_SESSION['name'] = $user_data['user_name'];
        $_SESSION['role'] = $user_data['role'];

        // Redirect berdasarkan role
        if ($user_data['role'] == 1) {
            header("Location: dashboard_admin.php"); // Role Admin
        } elseif ($user_data['role'] == 2) {
            header("Location: ../dashboard_user.php"); // Role User
        }
        exit();
    } else {
        // Jika login gagal
        echo "<script>alert('Email atau password salah, silakan coba lagi.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library_Tech - Login</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="../css/stylelogin.css" rel="stylesheet">
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="login-content">
                <div class="login-header">
                    <div class="logo">
                        <i class="fas fa-user-circle"></i>
                    </div>
                    <form method="POST" action="">
                        <div class="input-field">
                            <i class="fas fa-user"></i>
                            <input type="text" name="email" required>
                            <label>Email</label>
                        </div>
                        <div class="input-field">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="pwd" required>
                            <label>Password</label>
                        </div>
                        <div class="remember-forgot">
                            <label><input type="checkbox"> Remember me</label>
                            <a href="#">Forgot password?</a>
                        </div>
                        <button type="submit" name="login_btn" class="login-btn">LOGIN</button>
                    </form>
                </div>
            </div>
            <div class="welcome-section">
                <div class="welcome-text">
                    <h2>Welcome.</h2>
                    <p>to Library Tech Management System</p>
                </div>
                <div class="wave-group">
                    <div class="wave wave1"></div>
                    <div class="wave wave2"></div>
                    <div class="wave wave3"></div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
