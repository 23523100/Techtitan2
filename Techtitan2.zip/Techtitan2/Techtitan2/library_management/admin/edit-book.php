<?php
session_start();
include ('../connection.php');
$id = $_SESSION['id'];
$name = $_SESSION['name'];
if (empty($id)) {
    header("Location: index.php"); 
}

$id = $_GET['id'];
$fetch_query = mysqli_query($conn, "SELECT * FROM tbl_book WHERE id='$id'");
$row = mysqli_fetch_array($fetch_query);

if (isset($_REQUEST['save-book-btn'])) {
    $book_name = $_POST['book_name'];
    $category_name = $_POST['category_name'];
    $isbn = $_POST['isbn'];
    $author_name = $_POST['author_name'];
    $publisher_name = $_POST['publisher_name'];
    $quantity = $_POST['quantity'];
    $location_name = $_POST['location_name'];
    $availability = $_POST['availability'];

    // Handle file upload
    $image_column = "";
    if (!empty($_FILES['image']['name'])) {
        $image_name = time() . '_' . basename($_FILES['image']['name']);
        $target_file = "../uploads/" . $image_name;

        // Validate file type
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        if (in_array($_FILES['image']['type'], $allowed_types)) {
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                // Delete old image if it exists
                if (!empty($row['image']) && file_exists("../uploads/" . $row['image'])) {
                    unlink("../uploads/" . $row['image']);
                }
                $image_column = ", image='$image_name'";
            } else {
                echo "<script>alert('Failed to upload the image.');</script>";
            }
        } else {
            echo "<script>alert('Invalid file type. Only JPG, PNG, and GIF are allowed.');</script>";
        }
    }

    // Update book details
    $update_book = mysqli_query($conn, "UPDATE tbl_book SET 
        book_name='$book_name', 
        category='$category_name', 
        isbnno='$isbn', 
        author='$author_name', 
        publisher='$publisher_name', 
        quantity='$quantity', 
        place='$location_name', 
        availability='$availability' 
        $image_column 
        WHERE id='$id'");

    if ($update_book) {
        echo "<script>
            alert('Book updated successfully.');
            window.location.href='view-book.php';
        </script>";
    } else {
        echo "<script>alert('Error updating book.');</script>";
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
<?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Edit Book</a>
          </li>
        </ol>

  <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-info-circle"></i>
            Edit Details</div>
             
            <form method="post" enctype="multipart/form-data" class="form-valide">
          <div class="card-body">
  <div class="form-group row">
          <label class="col-lg-4 col-form-label" for="item">Nama Buku <span class="text-danger">*</span></label>
           <div class="col-lg-6">
          <input type="text" name="book_name" id="book_name" class="form-control" placeholder="Enter Book Name" required value="<?php echo $row['book_name']; ?>">
           </div>
      </div>         
          <div class="form-group row">
                <label class="col-lg-4 col-form-label" for="leave-type">Kategori <span class="text-danger">*</span>
                </label>
    <div class="col-lg-6">
        <select class="form-control" id="category_name" name="category_name" required>
            <option value="">Select Category</option>
            <?php 
             $fetch_category = mysqli_query($conn, "SELECT * FROM tbl_category WHERE status=1");
             while ($rows = mysqli_fetch_array($fetch_category)) {
            ?>
 <option <?php if ($rows['category_name'] == $row['category']) { ?>
    selected="selected" <?php } ?>><?php echo $rows['category_name']; ?>
</option>
        <?php } ?>
         </select>
    </div>
      </div>    
          
      <div class="form-group row">
          <label class="col-lg-4 col-form-label" for="isbn">ISBN <span class="text-danger">*</span></label>
           <div class="col-lg-6">
          <input type="text" name="isbn" id="isbn" class="form-control" placeholder="Enter ISBN" required value="<?php echo $row['isbnno']; ?>">
           </div>
      </div> 
      <div class="form-group row">
          <label class="col-lg-4 col-form-label" for="author_name">Penulis <span class="text-danger">*</span></label>
           <div class="col-lg-6">
          <input type="text" name="author_name" id="author_name" class="form-control" placeholder="Enter Author Name" required value="<?php echo $row['author']; ?>">
           </div>
      </div> 
      <div class="form-group row">
          <label class="col-lg-4 col-form-label" for="publisher_name">Penerbit <span class="text-danger">*</span></label>
           <div class="col-lg-6">
          <input type="text" name="publisher_name" id="publisher_name" class="form-control" placeholder="Enter Publisher Name" required value="<?php echo $row['publisher']; ?>">
           </div>
      </div> 
      
      <div class="form-group row">
          <label class="col-lg-4 col-form-label" for="quantity">Jumlah Buku <span class="text-danger">*</span></label>
           <div class="col-lg-6">
          <input type="text" name="quantity" id="quantity" class="form-control" placeholder="Enter Number of Copy" required value="<?php echo $row['quantity']; ?>">
           </div>
      </div>
      <div class="form-group row">
                <label class="col-lg-4 col-form-label" for="location_name">Lokasi <span class="text-danger">*</span>
                </label>
    <div class="col-lg-6">
        <select class="form-control" id="location_name" name="location_name" required>
            <option value="">Pilih Lokasi</option>
            <?php 
             $fetch_location = mysqli_query($conn, "SELECT * FROM tbl_location WHERE status=1");
             while ($rows = mysqli_fetch_array($fetch_location)) {
            ?>
            <option <?php if ($rows['name'] == $row['place']) { ?>
    selected="selected" <?php } ?>><?php echo $rows['name']; ?>
</option>
        <?php } ?>
         </select>
    </div>
      </div> 
      <div class="form-group row">
                <label class="col-lg-4 col-form-label" for="availability">Availability <span class="text-danger">*</span>
                </label>
                <div class="col-lg-6">
                    <select class="form-control" id="availability" name="availability" required>
                        <option value="">Select Status</option>
                       <option value="1" <?php if ($row['availability'] == 1) { ?> selected="selected" <?php } ?>>Tersedia</option>
                       <option value="0" <?php if ($row['availability'] == 0) { ?> selected="selected" <?php } ?>>Kosong</option>
                    </select>
                </div>
            </div>    
             
            <div class="form-group row">
    <label class="col-lg-4 col-form-label" for="image">Book Image</label>
    <div class="col-lg-6">
        <input type="file" name="image" id="image" class="form-control" />
        <!-- Display current image -->
        <img src="../uploads/<?php echo $row['image']; ?>" alt="Current Book Image" style="width: 100px; height: auto;">
    </div>
</div>
                            
            <div class="form-group row">
                <div class="col-lg-8 ml-auto">
                    <button type="submit" name="save-book-btn" class="btn btn-primary">Save</button>
                </div>
            </div>
        </div>
    </form>
</div>            
    </div>
</div>
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
 <?php include('include/footer.php'); ?>
