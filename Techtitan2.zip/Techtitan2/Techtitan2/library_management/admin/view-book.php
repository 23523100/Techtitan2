<?php
session_start();
include ('../connection.php');

// Validasi sesi admin
$name = isset($_SESSION['name']) ? $_SESSION['name'] : '';
$id = isset($_SESSION['id']) ? $_SESSION['id'] : '';
if(empty($id)) {
    header("Location: index.php"); 
    exit;
}

// Inisialisasi variabel pencarian
$search = '';
if (isset($_POST['search'])) {
    $search = mysqli_real_escape_string($conn, $_POST['search']); 
}

// Query untuk mengambil semua buku
$select_query = "SELECT * FROM tbl_book";
if (!empty($search)) {
    $select_query .= " WHERE book_name LIKE '%$search%' OR author LIKE '%$search%' OR category LIKE '%$search%'";
}
$select_query .= " ORDER BY id DESC";
$result = mysqli_query($conn, $select_query);

// Cek apakah ada buku
$has_books = mysqli_num_rows($result) > 0;
?>

<?php include('include/header.php'); ?>

<div id="wrapper">
    <?php include('include/side-bar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Kelola Buku</a>
                </li>
            </ol>

            <!-- Search Bar & Add Book Button -->
            <div class="card mb-3">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="m-0">Daftar Buku</h5>
                        <div class="d-flex gap-3">
                            <form method="POST" action="" class="search-form">
                                <div class="input-group">
                                    <input type="text" name="search" class="form-control" placeholder="Cari judul, penulis, atau kategori..." value="<?php echo htmlspecialchars($search); ?>">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                            <a href="tambah-buku.php" class="btn btn-success">
                                <i class="fas fa-plus"></i> Tambah Buku
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="card-body">
                    <?php if ($has_books) { ?>
                        <div class="container-fluid view-book">
                            <div class="row">
                                <?php while($row = mysqli_fetch_array($result)) { ?>
                                    <div class="col-md-3">
                                        <div class="book-card">
                                            <div class="book-cover">
                                                <img src="../uploads/<?php echo $row['image']; ?>" alt="<?php echo $row['book_name']; ?>">
                                                <div class="hover-info">
                                                    <h6><?php echo $row['book_name']; ?></h6>
                                                    <p class="author">Penulis: <?php echo $row['author']; ?></p>
                                                    <p class="category">Kategori: <?php echo $row['category']; ?></p>
                                                    <p class="stock">Stok: <?php echo $row['quantity']; ?></p>
                                                    <div class="action-buttons">
                                                        <a href="edit-book.php?id=<?php echo $row['id']; ?>" class="btn btn-edit">
                                                            <i class="fas fa-edit"></i> Edit
                                                        </a>
                                                        <a href="view-book.php?ids=<?php echo $row['id']; ?>" onclick="return confirmDelete()" class="btn btn-delete">
                                                            <i class="fas fa-trash"></i> Hapus
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    <?php } else { ?>
                        <div class="empty-state">
                            <div class="empty-state-icon">
                                <i class="fas fa-books"></i>
                            </div>
                            <h3>Belum Ada Buku</h3>
                            <p>Mulai tambahkan buku ke perpustakaan.</p>
                            <a href="add-book.php" class="btn btn-primary">Tambah Buku</a>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Search Form & Add Button */
.search-form {
    max-width: 400px;
    width: 100%;
}

.search-form .input-group {
    border-radius: 25px;
    overflow: hidden;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

.search-form .form-control {
    border: none;
    padding: 12px 20px;
}

.gap-3 {
    gap: 1rem;
}

.btn-success {
    background: linear-gradient(45deg, #2ecc71, #27ae60);
    border: none;
    padding: 8px 20px;
    border-radius: 25px;
}

/* Book Card Styling */
.book-card {
    margin-bottom: 30px;
    transition: all 0.3s ease;
}

.book-cover {
    position: relative;
    overflow: hidden;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.book-cover img {
    width: 100%;
    height: 350px;
    object-fit: cover;
    transition: all 0.3s ease;
}

.hover-info {
    position: absolute;
    bottom: -100%;
    left: 0;
    width: 100%;
    padding: 20px;
    background: linear-gradient(to top, rgba(0,0,0,0.9), rgba(0,0,0,0.7));
    color: white;
    transition: all 0.3s ease;
}

.book-cover:hover .hover-info {
    bottom: 0;
}

.book-cover:hover img {
    transform: scale(1.05);
}

.hover-info h6 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 8px;
}

.hover-info .author,
.hover-info .category,
.hover-info .stock {
    font-size: 14px;
    margin-bottom: 5px;
    opacity: 0.8;
}

.action-buttons {
    display: flex;
    gap: 10px;
    margin-top: 15px;
}

.btn-edit,
.btn-delete {
    flex: 1;
    padding: 8px 15px;
    border-radius: 25px;
    font-size: 14px;
    font-weight: 600;
    text-transform: uppercase;
    transition: all 0.3s ease;
    text-decoration: none;
    text-align: center;
}

.btn-edit {
    background: linear-gradient(45deg, #4facfe, #00f2fe);
    color: white;
}

.btn-delete {
    background: linear-gradient(45deg, #ff416c, #ff4b2b);
    color: white;
}

.btn-edit:hover,
.btn-delete:hover {
    transform: translateY(-2px);
    color: white;
    text-decoration: none;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 40px 20px;
}

.empty-state-icon {
    font-size: 48px;
    color: #ccc;
    margin-bottom: 20px;
}

.empty-state h3 {
    color: #333;
    font-size: 24px;
    margin-bottom: 10px;
}

.empty-state p {
    color: #666;
    margin-bottom: 20px;
}

.empty-state .btn {
    background: linear-gradient(45deg, #4facfe, #00f2fe);
    border: none;
    padding: 10px 30px;
    border-radius: 25px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.empty-state .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(79, 172, 254, 0.3);
}

/* Responsive Adjustments */
@media (max-width: 1200px) {
    .book-cover img {
        height: 300px;
    }
}

@media (max-width: 992px) {
    .book-cover img {
        height: 280px;
    }
    
    .gap-3 {
        flex-direction: column;
    }
    
    .search-form {
        max-width: 100%;
    }
}

@media (max-width: 768px) {
    .book-cover img {
        height: 400px;
    }
}

@media (max-width: 576px) {
    .book-cover img {
        height: 350px;
    }
    
    .hover-info {
        padding: 15px;
    }
    
    .action-buttons {
        flex-direction: column;
    }
}
</style>

<script>
function confirmDelete(){
    return confirm('Apakah Anda yakin ingin menghapus buku ini?');
}
</script>

<?php include('include/footer.php'); ?>