
<ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="dashboard_admin.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white;">
          <i class="fa fa-book"></i>
          <span>Buku</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <a class="dropdown-item" href="tambah-buku.php">Tambah Buku</a>
          <a class="dropdown-item" href="view-book.php">Lihat Buku</a>
      </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white;">
          <i class="fa fa-list-alt"></i>
          <span>Kategori</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <a class="dropdown-item" href="add-category.php">Tambah Kategori</a>
          <a class="dropdown-item" href="view-category.php">Lihat Kategori</a>
      </div>
      </li>
       <li class="nav-item ">
        <a class="nav-link " href="issue-request.php" style="color: white;">
          <i class="fa fa-paper-plane"></i>
          <span>Requests Peminjaman</span>
        </a>
        
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white;">
          <i class="fa fa-map-marker"></i>
          <span>Setting Lokasi</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <a class="dropdown-item" href="add-place.php">Tambah Lokasi</a>
          <a class="dropdown-item" href="view-place.php">Lihat Lokasi</a>
      </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white;">
          <i class="fa fa-user"></i>
          <span>Akun User</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <a class="dropdown-item" href="add-users.php">Tambah User</a>
          <a class="dropdown-item" href="view-users.php">Lihat User</a>
      </div>
      </li>
     </ul>

   